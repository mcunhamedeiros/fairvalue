function results = rollingAdaLassoUSDSEK(varargin)
%ROLLINGADALASSOUSDSEK Rolling-window adaptive lasso for USDSEK.
%
% Example:
%   results = rollingAdaLassoUSDSEK;
%
% Custom window lengths:
%   results = rollingAdaLassoUSDSEK("EstimationWindow", 756, ...
%       "TestWindow", 20, "StepSize", 1);
%
% The function expects a table or timetable named "data" in DataFile. The
% dependent variable is USDSEK and all other numeric variables are used as
% regressors. By default, figures are opened on screen and saved as PNGs.
% Out-of-sample R2 uses the training-window mean as the benchmark.
% The function also reports OOS R2 against the last USDSEK observation in
% the training window.
% The function also reports squared-correlation R2, which is bounded
% between 0 and 1 when both series have nonzero variance.
% By default, it also runs an Augmented Dickey-Fuller unit-root test on the
% in-sample residuals in each window.
% Coefficient plots use standardized effects, beta_j times the in-sample
% standard deviation of regressor j, so coefficients are comparable.
% Coefficient turnover is computed from those standardized effects.

p = inputParser;
addParameter(p, "DataFile", ...
    "C:\Users\marcelom\Dropbox\Consulting\ITAUAM AI\AUDCAD Fairvalue\SEK\dados_sek.mat");
addParameter(p, "LassoFunctionFolder", ...
    "C:\Users\marcelom\Dropbox\Consulting\ITAUAM AI\AUDCAD Fairvalue");
addParameter(p, "DependentVariable", "USDSEK");
addParameter(p, "EstimationWindow", 756);
addParameter(p, "TestWindow", 20);
addParameter(p, "StepSize", 1);
addParameter(p, "MinimumTrainObservations", 50);
addParameter(p, "MinimumTestObservations", 2);
addParameter(p, "MaxWindows", Inf);
addParameter(p, "OutputFolder", fullfile(fileparts(mfilename("fullpath")), ...
    "rolling_adalasso_usdsek_outputs"));
addParameter(p, "MakePlots", true);
addParameter(p, "ShowPlots", true);
addParameter(p, "MakeNegativeOOSPlots", true);
addParameter(p, "NegativeOOSPlotFolder", "");
addParameter(p, "SaveNegativeOOSDiagnostics", true);
addParameter(p, "NegativeOOSTopDrivers", 10);
addParameter(p, "RunUnitRootTest", true);
addParameter(p, "UnitRootModel", "AR");
addParameter(p, "UnitRootLags", 0);
addParameter(p, "UnitRootAlpha", 0.05);
addParameter(p, "Verbose", true);
parse(p, varargin{:});
cfg = p.Results;

cfg.DataFile = char(cfg.DataFile);
cfg.LassoFunctionFolder = char(cfg.LassoFunctionFolder);
cfg.DependentVariable = char(cfg.DependentVariable);
cfg.OutputFolder = char(cfg.OutputFolder);
cfg.NegativeOOSPlotFolder = char(cfg.NegativeOOSPlotFolder);
cfg.UnitRootModel = char(cfg.UnitRootModel);
if isempty(cfg.NegativeOOSPlotFolder)
    cfg.NegativeOOSPlotFolder = fullfile(cfg.OutputFolder, "negative_oos_plots");
end

validateattributes(cfg.EstimationWindow, {'numeric'}, ...
    {'scalar','integer','positive'}, mfilename, "EstimationWindow");
validateattributes(cfg.TestWindow, {'numeric'}, ...
    {'scalar','integer','positive'}, mfilename, "TestWindow");
validateattributes(cfg.StepSize, {'numeric'}, ...
    {'scalar','integer','positive'}, mfilename, "StepSize");
validateattributes(cfg.MinimumTrainObservations, {'numeric'}, ...
    {'scalar','integer','positive'}, mfilename, "MinimumTrainObservations");
validateattributes(cfg.MinimumTestObservations, {'numeric'}, ...
    {'scalar','integer','positive'}, mfilename, "MinimumTestObservations");
validateattributes(cfg.UnitRootLags, {'numeric'}, ...
    {'scalar','integer','nonnegative'}, mfilename, "UnitRootLags");
validateattributes(cfg.UnitRootAlpha, {'numeric'}, ...
    {'scalar','>',0,'<',1}, mfilename, "UnitRootAlpha");
validateattributes(cfg.NegativeOOSTopDrivers, {'numeric'}, ...
    {'scalar','integer','positive'}, mfilename, "NegativeOOSTopDrivers");

if ~exist(cfg.DataFile, "file")
    error("Data file not found: %s", cfg.DataFile);
end
if ~exist(cfg.LassoFunctionFolder, "dir")
    error("Lasso function folder not found: %s", cfg.LassoFunctionFolder);
end

addpath(cfg.LassoFunctionFolder);
if exist("computeBetaAdaLasso", "file") ~= 2
    error("computeBetaAdaLasso.m was not found on the MATLAB path.");
end

loaded = load(cfg.DataFile);
if ~isfield(loaded, "data")
    error('Data file must contain a table or timetable named "data".');
end

data = loaded.data;
if ~(istable(data) || istimetable(data))
    error('"data" must be a MATLAB table or timetable.');
end
if ~ismember(cfg.DependentVariable, data.Properties.VariableNames)
    error('Dependent variable "%s" was not found in data.', cfg.DependentVariable);
end
if ~isnumeric(data.(cfg.DependentVariable))
    error('Dependent variable "%s" must be numeric.', cfg.DependentVariable);
end

allVariableNames = data.Properties.VariableNames;
candidateRegressorNames = setdiff(allVariableNames, {cfg.DependentVariable}, "stable");
isNumericRegressor = varfun(@isnumeric, data(:, candidateRegressorNames), ...
    "OutputFormat", "uniform");
regressorNames = candidateRegressorNames(isNumericRegressor);
droppedRegressors = candidateRegressorNames(~isNumericRegressor);

if isempty(regressorNames)
    error("No numeric regressors were found.");
end
if ~isempty(droppedRegressors)
    warning("Dropped nonnumeric regressors: %s", strjoin(droppedRegressors, ", "));
end

Yall = data.(cfg.DependentVariable);
Xall = table2array(data(:, regressorNames));
obsAxis = localObservationAxis(data);
nObs = height(data);
nRegressors = numel(regressorNames);

lastStart = nObs - cfg.EstimationWindow - cfg.TestWindow + 1;
if lastStart < 1
    error("The sample is too short for the requested estimation and test windows.");
end

windowStarts = 1:cfg.StepSize:lastStart;
if isfinite(cfg.MaxWindows)
    windowStarts = windowStarts(1:min(numel(windowStarts), cfg.MaxWindows));
end
nWindows = numel(windowStarts);

coef = NaN(nWindows, nRegressors + 1);
standardizedCoef = NaN(nWindows, nRegressors);
regressorStd = NaN(nWindows, nRegressors);
r2InSample = NaN(nWindows, 1);
r2OutOfSample = NaN(nWindows, 1);
r2OutOfSampleVsTrainMean = NaN(nWindows, 1);
r2OutOfSampleVsLastTrainY = NaN(nWindows, 1);
corr2InSample = NaN(nWindows, 1);
corr2OutOfSample = NaN(nWindows, 1);
rmseInSample = NaN(nWindows, 1);
rmseOutOfSample = NaN(nWindows, 1);
maeOutOfSample = NaN(nWindows, 1);
testStd = NaN(nWindows, 1);
testRange = NaN(nWindows, 1);
lastTrainUSDSEK = NaN(nWindows, 1);
lastTrainFitted = NaN(nWindows, 1);
lastTrainResidual = NaN(nWindows, 1);
recentTrainRMSE = NaN(nWindows, 1);
unitRootReject = NaN(nWindows, 1);
unitRootPValue = NaN(nWindows, 1);
unitRootStatistic = NaN(nWindows, 1);
unitRootCriticalValue = NaN(nWindows, 1);
unitRootStatus = repmat({""}, nWindows, 1);
nTrainUsed = NaN(nWindows, 1);
nTestUsed = NaN(nWindows, 1);
activeRegressorCount = NaN(nWindows, 1);
status = repmat({""}, nWindows, 1);
negativeOOSPlotFile = repmat({""}, nWindows, 1);
predictionRows = cell(nWindows, 1);
negativeOOSDriverRows = cell(nWindows, 1);

trainStartObs = obsAxis(windowStarts(:));
trainEndObs = obsAxis(windowStarts(:) + cfg.EstimationWindow - 1);
testStartObs = obsAxis(windowStarts(:) + cfg.EstimationWindow);
testEndObs = obsAxis(windowStarts(:) + cfg.EstimationWindow + cfg.TestWindow - 1);

if cfg.Verbose
    fprintf("Running %d rolling windows with %d regressors.\n", nWindows, nRegressors);
end

if ~exist(cfg.OutputFolder, "dir")
    mkdir(cfg.OutputFolder);
end
if cfg.MakeNegativeOOSPlots && ~exist(cfg.NegativeOOSPlotFolder, "dir")
    mkdir(cfg.NegativeOOSPlotFolder);
end

for k = 1:nWindows
    trainIdx = windowStarts(k):(windowStarts(k) + cfg.EstimationWindow - 1);
    testIdx = (trainIdx(end) + 1):(trainIdx(end) + cfg.TestWindow);

    yTrainRaw = Yall(trainIdx);
    xTrainRaw = Xall(trainIdx, :);
    yTestRaw = Yall(testIdx);
    xTestRaw = Xall(testIdx, :);

    trainGood = isfinite(yTrainRaw) & all(isfinite(xTrainRaw), 2);
    testGood = isfinite(yTestRaw) & all(isfinite(xTestRaw), 2);

    yTrain = yTrainRaw(trainGood);
    xTrain = xTrainRaw(trainGood, :);
    yTest = yTestRaw(testGood);
    xTest = xTestRaw(testGood, :);

    nTrainUsed(k) = numel(yTrain);
    nTestUsed(k) = numel(yTest);

    if nTrainUsed(k) < cfg.MinimumTrainObservations
        status{k} = "Skipped: too few usable training observations";
        continue
    end
    if nTestUsed(k) < cfg.MinimumTestObservations
        status{k} = "Skipped: too few usable test observations";
        continue
    end

    try
        [b, e] = computeBetaAdaLasso(yTrain, xTrain);
        b = b(:);
        coef(k, :) = b.';
        regressorStd(k, :) = std(xTrain, 0, 1);
        standardizedCoef(k, :) = b(2:end).' .* regressorStd(k, :);
        activeRegressorCount(k) = sum(abs(b(2:end)) > 0);

        yHatTrain = [ones(numel(yTrain), 1), xTrain] * b;
        yHatTest = [ones(numel(yTest), 1), xTest] * b;

        r2InSample(k) = 1 - sum(e(:).^2) / sum((yTrain - mean(yTrain)).^2);
        r2OutOfSample(k) = localR2(yTest, yHatTest, mean(yTrain));
        r2OutOfSampleVsTrainMean(k) = localR2(yTest, yHatTest, mean(yTrain));
        r2OutOfSampleVsLastTrainY(k) = localR2(yTest, yHatTest, yTrain(end));
        corr2InSample(k) = localCorr2(yTrain, yHatTrain);
        corr2OutOfSample(k) = localCorr2(yTest, yHatTest);
        rmseInSample(k) = sqrt(mean((yTrain - yHatTrain).^2));
        rmseOutOfSample(k) = sqrt(mean((yTest - yHatTest).^2));
        maeOutOfSample(k) = mean(abs(yTest - yHatTest));
        testStd(k) = std(yTest);
        testRange(k) = max(yTest) - min(yTest);
        lastTrainUSDSEK(k) = yTrain(end);
        lastTrainFitted(k) = yHatTrain(end);
        lastTrainResidual(k) = yTrain(end) - yHatTrain(end);
        recentBlock = max(1, numel(yTrain) - cfg.TestWindow + 1):numel(yTrain);
        recentTrainRMSE(k) = sqrt(mean((yTrain(recentBlock) - yHatTrain(recentBlock)).^2));

        [unitRootReject(k), unitRootPValue(k), unitRootStatistic(k), ...
            unitRootCriticalValue(k), unitRootStatus{k}] = ...
            localUnitRootTest(e(:), cfg);

        if r2OutOfSample(k) < 0 && ...
                (cfg.MakeNegativeOOSPlots || cfg.SaveNegativeOOSDiagnostics)
            windowDriverTable = localNegativeOOSDrivers(k, ...
                windowStarts(k), trainStartObs(k), trainEndObs(k), ...
                testStartObs(k), testEndObs(k), yTrain, xTrain, yTest, ...
                xTest, yHatTest, b, regressorNames, r2OutOfSample(k));
        else
            windowDriverTable = table();
        end

        if cfg.MakeNegativeOOSPlots && r2OutOfSample(k) < 0
            negativeOOSPlotFile{k} = fullfile(cfg.NegativeOOSPlotFolder, ...
                sprintf("negative_oos_window_%04d.png", k));
            localPlotNegativeOOSDiagnostic(obsAxis(testIdx(testGood)), ...
                yTest, yHatTest, mean(yTrain), windowDriverTable, ...
                r2OutOfSample(k), negativeOOSPlotFile{k}, ...
                cfg.NegativeOOSTopDrivers);
        end

        if cfg.SaveNegativeOOSDiagnostics && r2OutOfSample(k) < 0
            negativeOOSDriverRows{k} = windowDriverTable;
        end

        predictionRows{k} = table( ...
            repmat(k, numel(yTest), 1), ...
            obsAxis(testIdx(testGood)), ...
            yTest, yHatTest, yTest - yHatTest, ...
            repmat(mean(yTrain), numel(yTest), 1), ...
            repmat(yTrain(end), numel(yTest), 1), ...
            'VariableNames', {'Window','Observation','USDSEK', ...
            'Prediction','Error','TrainMean','LastTrainUSDSEK'});
        status{k} = "OK";
    catch ME
        status{k} = "Skipped: " + string(ME.message);
    end

    if cfg.Verbose && (mod(k, 100) == 0 || k == nWindows)
        fprintf("Finished %d of %d windows.\n", k, nWindows);
    end
end

windowInfo = table((1:nWindows).', windowStarts(:), trainStartObs(:), ...
    trainEndObs(:), testStartObs(:), testEndObs(:), ...
    'VariableNames', {'Window','StartIndex','TrainStart','TrainEnd', ...
    'TestStart','TestEnd'});

coefNames = [{'Intercept'}, regressorNames];
coefTable = [windowInfo, array2table(coef, 'VariableNames', coefNames)];
standardizedCoefTable = [windowInfo, array2table(standardizedCoef, ...
    'VariableNames', regressorNames)];
regressorStdTable = [windowInfo, array2table(regressorStd, ...
    'VariableNames', regressorNames)];
averageCoefficientTable = table(regressorNames(:), ...
    localColumnMean(coef(:, 2:end)).', ...
    localColumnMean(standardizedCoef).', ...
    localColumnMean(regressorStd).', ...
    'VariableNames', {'Regressor','AverageRawCoefficient', ...
    'AverageStandardizedCoefficient','AverageInSampleStd'});
turnoverTable = localCoefficientTurnover(windowInfo, standardizedCoef);
metricTable = [windowInfo, table(nTrainUsed, nTestUsed, activeRegressorCount, ...
    r2InSample, r2OutOfSample, r2OutOfSampleVsTrainMean, ...
    r2OutOfSampleVsLastTrainY, corr2InSample, corr2OutOfSample, ...
    rmseInSample, rmseOutOfSample, maeOutOfSample, testStd, testRange, ...
    lastTrainUSDSEK, lastTrainFitted, lastTrainResidual, recentTrainRMSE, ...
    unitRootReject, unitRootPValue, unitRootStatistic, ...
    unitRootCriticalValue, unitRootStatus, ...
    negativeOOSPlotFile, status, ...
    'VariableNames', {'TrainObservations','TestObservations', ...
    'ActiveRegressors','R2InSample','R2OutOfSample', ...
    'R2OutOfSampleVsTrainMean','R2OutOfSampleVsLastTrainY', ...
    'Corr2InSample','Corr2OutOfSample', ...
    'RMSEInSample','RMSEOutOfSample','MAEOutOfSample', ...
    'TestStd','TestRange','LastTrainUSDSEK','LastTrainFitted', ...
    'LastTrainResidual','RecentTrainRMSE', ...
    'UnitRootReject','UnitRootPValue','UnitRootStatistic', ...
    'UnitRootCriticalValue','UnitRootStatus','NegativeOOSPlotFile', ...
    'Status'})];

unitRootTable = [windowInfo, table(unitRootReject, unitRootPValue, ...
    unitRootStatistic, unitRootCriticalValue, unitRootStatus, ...
    'VariableNames', {'UnitRootReject','UnitRootPValue', ...
    'UnitRootStatistic','UnitRootCriticalValue','UnitRootStatus'})];

predictionRows = predictionRows(~cellfun("isempty", predictionRows));
if isempty(predictionRows)
    predictionTable = table();
else
    predictionTable = vertcat(predictionRows{:});
end

negativeOOSDriverRows = negativeOOSDriverRows(~cellfun("isempty", negativeOOSDriverRows));
if isempty(negativeOOSDriverRows)
    negativeOOSDriverTable = localEmptyNegativeOOSDriverTable();
else
    negativeOOSDriverTable = vertcat(negativeOOSDriverRows{:});
end

results = struct();
results.config = cfg;
results.regressorNames = regressorNames;
results.coefficients = coefTable;
results.standardizedCoefficients = standardizedCoefTable;
results.regressorStandardDeviations = regressorStdTable;
results.averageCoefficients = averageCoefficientTable;
results.coefficientTurnover = turnoverTable;
results.metrics = metricTable;
results.unitRoot = unitRootTable;
results.predictions = predictionTable;
results.negativeOOSDrivers = negativeOOSDriverTable;
results.coefficientMatrix = coef;
results.standardizedCoefficientMatrix = standardizedCoef;
results.r2InSample = r2InSample;
results.r2OutOfSample = r2OutOfSample;
results.r2OutOfSampleVsTrainMean = r2OutOfSampleVsTrainMean;
results.r2OutOfSampleVsLastTrainY = r2OutOfSampleVsLastTrainY;
results.corr2InSample = corr2InSample;
results.corr2OutOfSample = corr2OutOfSample;
results.plotFiles = struct( ...
    "r2", fullfile(cfg.OutputFolder, "rollingAdaLasso_R2.png"), ...
    "corr2", fullfile(cfg.OutputFolder, "rollingAdaLasso_corr2.png"), ...
    "coefficients", fullfile(cfg.OutputFolder, "rollingAdaLasso_coefficients.png"), ...
    "averageCoefficients", fullfile(cfg.OutputFolder, ...
    "rollingAdaLasso_average_coefficients.png"), ...
    "coefficientTurnover", fullfile(cfg.OutputFolder, ...
    "rollingAdaLasso_coefficient_turnover.png"), ...
    "negativeOOSDrivers", fullfile(cfg.OutputFolder, ...
    "rollingAdaLassoNegativeOOSDrivers.csv"), ...
    "negativeOOSDriverHeatmap", fullfile(cfg.OutputFolder, ...
    "negative_oos_driver_heatmap.png"), ...
    "negativeOOSDriverTotals", fullfile(cfg.OutputFolder, ...
    "negative_oos_driver_totals.png"), ...
    "negativeOOSFolder", cfg.NegativeOOSPlotFolder);

if ~exist(cfg.OutputFolder, "dir")
    mkdir(cfg.OutputFolder);
end

save(fullfile(cfg.OutputFolder, "rollingAdaLassoResults.mat"), "results");
writetable(coefTable, fullfile(cfg.OutputFolder, "rollingAdaLassoCoefficients.csv"));
writetable(standardizedCoefTable, ...
    fullfile(cfg.OutputFolder, "rollingAdaLassoStandardizedCoefficients.csv"));
writetable(regressorStdTable, ...
    fullfile(cfg.OutputFolder, "rollingAdaLassoRegressorStd.csv"));
writetable(averageCoefficientTable, ...
    fullfile(cfg.OutputFolder, "rollingAdaLassoAverageCoefficients.csv"));
writetable(turnoverTable, ...
    fullfile(cfg.OutputFolder, "rollingAdaLassoCoefficientTurnover.csv"));
writetable(metricTable, fullfile(cfg.OutputFolder, "rollingAdaLassoR2.csv"));
writetable(unitRootTable, fullfile(cfg.OutputFolder, "rollingAdaLassoUnitRoot.csv"));
writetable(negativeOOSDriverTable, ...
    fullfile(cfg.OutputFolder, "rollingAdaLassoNegativeOOSDrivers.csv"));
if ~isempty(predictionTable)
    writetable(predictionTable, ...
        fullfile(cfg.OutputFolder, "rollingAdaLassoPredictions.csv"));
end

if cfg.MakePlots
    localPlotR2(metricTable, results.plotFiles.r2, cfg.ShowPlots);
    localPlotCorr2(metricTable, results.plotFiles.corr2, cfg.ShowPlots);
    localPlotCoefficients(standardizedCoefTable, regressorNames, ...
        results.plotFiles.coefficients, cfg.ShowPlots);
    localPlotAverageCoefficients(averageCoefficientTable, ...
        results.plotFiles.averageCoefficients, cfg.ShowPlots);
    localPlotCoefficientTurnover(turnoverTable, ...
        results.plotFiles.coefficientTurnover, cfg.ShowPlots);
    if ~isempty(negativeOOSDriverTable)
        localPlotNegativeOOSDriverHeatmap(negativeOOSDriverTable, ...
            results.plotFiles.negativeOOSDriverHeatmap, cfg.ShowPlots);
        localPlotNegativeOOSDriverTotals(negativeOOSDriverTable, ...
            results.plotFiles.negativeOOSDriverTotals, cfg.ShowPlots);
    end
end

if cfg.Verbose
    fprintf("Saved results to: %s\n", cfg.OutputFolder);
    if cfg.MakePlots
        fprintf("Saved R2 plot to: %s\n", results.plotFiles.r2);
        fprintf("Saved squared-correlation R2 plot to: %s\n", results.plotFiles.corr2);
        fprintf("Saved standardized coefficient plot to: %s\n", results.plotFiles.coefficients);
        fprintf("Saved average coefficient plot to: %s\n", results.plotFiles.averageCoefficients);
        fprintf("Saved coefficient turnover plot to: %s\n", results.plotFiles.coefficientTurnover);
        if cfg.MakeNegativeOOSPlots
            fprintf("Saved negative OOS plots to: %s\n", results.plotFiles.negativeOOSFolder);
        end
        if cfg.SaveNegativeOOSDiagnostics
            fprintf("Saved negative OOS driver diagnostics to: %s\n", results.plotFiles.negativeOOSDrivers);
            if ~isempty(negativeOOSDriverTable)
                fprintf("Saved negative OOS driver heatmap to: %s\n", results.plotFiles.negativeOOSDriverHeatmap);
                fprintf("Saved negative OOS driver totals to: %s\n", results.plotFiles.negativeOOSDriverTotals);
            end
        end
    end
end
end

function obsAxis = localObservationAxis(data)
if istimetable(data)
    obsAxis = data.Properties.RowTimes;
elseif ismember("Date", data.Properties.VariableNames)
    obsAxis = data.Date;
else
    obsAxis = (1:height(data)).';
end
obsAxis = obsAxis(:);
end

function r2 = localR2(y, yHat, benchmark)
denominator = sum((y - benchmark).^2);
if denominator <= eps
    r2 = NaN;
else
    r2 = 1 - sum((y - yHat).^2) / denominator;
end
end

function m = localColumnMean(X)
m = NaN(1, size(X, 2));
for j = 1:size(X, 2)
    good = isfinite(X(:, j));
    if any(good)
        m(j) = mean(X(good, j));
    end
end
end

function turnoverTable = localCoefficientTurnover(windowInfo, standardizedCoef)
nWindows = size(standardizedCoef, 1);
absoluteTurnover = NaN(nWindows, 1);
normalizedTurnover = NaN(nWindows, 1);
meanAbsChange = NaN(nWindows, 1);
maxAbsChange = NaN(nWindows, 1);
activeRegressors = sum(abs(standardizedCoef) > 0 & isfinite(standardizedCoef), 2);
regressorsAdded = NaN(nWindows, 1);
regressorsDropped = NaN(nWindows, 1);

for k = 2:nWindows
    currentCoef = standardizedCoef(k, :);
    previousCoef = standardizedCoef(k - 1, :);
    good = isfinite(currentCoef) & isfinite(previousCoef);
    if ~any(good)
        continue
    end

    delta = currentCoef(good) - previousCoef(good);
    previousScale = sum(abs(previousCoef(good)));
    absoluteTurnover(k) = sum(abs(delta));
    meanAbsChange(k) = mean(abs(delta));
    maxAbsChange(k) = max(abs(delta));
    normalizedTurnover(k) = absoluteTurnover(k) / max(previousScale, eps);

    currentActive = abs(currentCoef(good)) > 0;
    previousActive = abs(previousCoef(good)) > 0;
    regressorsAdded(k) = sum(currentActive & ~previousActive);
    regressorsDropped(k) = sum(~currentActive & previousActive);
end

turnoverTable = [windowInfo, table(absoluteTurnover, normalizedTurnover, ...
    meanAbsChange, maxAbsChange, activeRegressors, regressorsAdded, ...
    regressorsDropped, ...
    'VariableNames', {'AbsoluteCoefficientTurnover', ...
    'NormalizedCoefficientTurnover','MeanAbsCoefficientChange', ...
    'MaxAbsCoefficientChange','ActiveRegressors', ...
    'RegressorsAdded','RegressorsDropped'})];
end

function driverTable = localNegativeOOSDrivers(windowNumber, startIndex, ...
    trainStart, trainEnd, testStart, testEnd, yTrain, xTrain, yTest, ...
    xTest, yHatTest, b, regressorNames, r2OutOfSample)

nRegressors = numel(regressorNames);
nTerms = nRegressors + 1;
benchmark = mean(yTrain);
benchmarkError = yTest - benchmark;
modelError = yTest - yHatTest;
totalBenchmarkGap = yHatTest - benchmark;

termNames = ["Intercept"; string(regressorNames(:))];
termTypes = ["Intercept"; repmat("Regressor", nRegressors, 1)];
rawBeta = b(:);
inSampleStd = [NaN; std(xTrain, 0, 1).'];
standardizedBeta = [NaN; b(2:end) .* inSampleStd(2:end)];
trainMeanX = [NaN; mean(xTrain, 1).'];
testMeanX = [NaN; mean(xTest, 1).'];

termForecastContribution = [ ...
    repmat(b(1), numel(yTest), 1), ...
    xTest .* b(2:end).'];
termBenchmarkGap = termForecastContribution;
termBenchmarkGap(:, 1) = termBenchmarkGap(:, 1) - benchmark;

meanForecastContribution = mean(termForecastContribution, 1).';
meanBenchmarkGapContribution = mean(termBenchmarkGap, 1).';
meanAbsBenchmarkGapContribution = mean(abs(termBenchmarkGap), 1).';

% Additive decomposition of model excess SSE relative to the benchmark:
% SSE_model - SSE_benchmark = sum_i term_i * (yHat - benchmark - 2 * benchmarkError).
excessSSEContribution = sum(termBenchmarkGap .* ...
    (totalBenchmarkGap - 2 * benchmarkError), 1).';
positiveContribution = max(excessSSEContribution, 0);
totalPositiveContribution = sum(positiveContribution);
positiveExcessSSEShare = NaN(nTerms, 1);
if totalPositiveContribution > eps
    positiveExcessSSEShare = positiveContribution / totalPositiveContribution;
end

driverRank = NaN(nTerms, 1);
[sortedPositiveContribution, driverOrder] = sort(positiveContribution, "descend");
for j = 1:nTerms
    if sortedPositiveContribution(j) > 0
        driverRank(driverOrder(j)) = j;
    end
end

modelSSE = sum(modelError.^2);
benchmarkSSE = sum(benchmarkError.^2);
excessSSE = modelSSE - benchmarkSSE;

driverTable = table( ...
    repmat(windowNumber, nTerms, 1), ...
    repmat(startIndex, nTerms, 1), ...
    repmat(trainStart, nTerms, 1), ...
    repmat(trainEnd, nTerms, 1), ...
    repmat(testStart, nTerms, 1), ...
    repmat(testEnd, nTerms, 1), ...
    driverRank, termNames, termTypes, rawBeta, inSampleStd, ...
    standardizedBeta, trainMeanX, testMeanX, meanForecastContribution, ...
    meanBenchmarkGapContribution, meanAbsBenchmarkGapContribution, ...
    excessSSEContribution, positiveExcessSSEShare, ...
    repmat(modelSSE, nTerms, 1), ...
    repmat(benchmarkSSE, nTerms, 1), ...
    repmat(excessSSE, nTerms, 1), ...
    repmat(r2OutOfSample, nTerms, 1), ...
    repmat(benchmark, nTerms, 1), ...
    repmat(mean(yTest), nTerms, 1), ...
    repmat(mean(yHatTest), nTerms, 1), ...
    'VariableNames', localNegativeOOSDriverVariableNames());
end

function driverTable = localEmptyNegativeOOSDriverTable()
driverTable = table( ...
    zeros(0, 1), zeros(0, 1), NaT(0, 1), NaT(0, 1), ...
    NaT(0, 1), NaT(0, 1), zeros(0, 1), strings(0, 1), ...
    strings(0, 1), zeros(0, 1), zeros(0, 1), zeros(0, 1), ...
    zeros(0, 1), zeros(0, 1), zeros(0, 1), zeros(0, 1), ...
    zeros(0, 1), zeros(0, 1), zeros(0, 1), zeros(0, 1), ...
    zeros(0, 1), zeros(0, 1), zeros(0, 1), zeros(0, 1), ...
    zeros(0, 1), zeros(0, 1), ...
    'VariableNames', localNegativeOOSDriverVariableNames());
end

function variableNames = localNegativeOOSDriverVariableNames()
variableNames = {'Window','StartIndex','TrainStart','TrainEnd', ...
    'TestStart','TestEnd','DriverRank','Term','TermType','RawBeta', ...
    'InSampleStd','StandardizedBeta','TrainMeanX','TestMeanX', ...
    'MeanForecastContribution','MeanBenchmarkGapContribution', ...
    'MeanAbsBenchmarkGapContribution','ExcessSSEContribution', ...
    'PositiveExcessSSEShare','ModelSSE','BenchmarkSSE','ExcessSSE', ...
    'R2OutOfSample','TrainMeanUSDSEK','TestMeanUSDSEK','MeanYHatTest'};
end

function c2 = localCorr2(y, yHat)
if numel(y) < 2 || std(y) <= eps || std(yHat) <= eps
    c2 = NaN;
else
    C = corrcoef(y, yHat);
    c2 = C(1, 2)^2;
end
end

function [reject, pValue, stat, criticalValue, testStatus] = localUnitRootTest(residuals, cfg)
reject = NaN;
pValue = NaN;
stat = NaN;
criticalValue = NaN;

if ~cfg.RunUnitRootTest
    testStatus = "Skipped";
    return
end
if exist("adftest", "file") ~= 2
    testStatus = "Skipped: adftest not found";
    return
end

residuals = residuals(isfinite(residuals));
if numel(residuals) <= cfg.UnitRootLags + 5
    testStatus = "Skipped: too few residuals";
    return
end

try
    [h, p, testStat, cValue] = adftest(residuals, ...
        "Model", cfg.UnitRootModel, ...
        "Lags", cfg.UnitRootLags, ...
        "Alpha", cfg.UnitRootAlpha);
    reject = double(h(1));
    pValue = p(1);
    stat = testStat(1);
    criticalValue = cValue(1);
    testStatus = "OK";
catch ME
    testStatus = "Skipped: " + string(ME.message);
end
end

function localPlotR2(metricTable, fileName, showPlot)
x = metricTable.TrainEnd;
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot));
tiledlayout(2, 1, "TileSpacing", "compact", "Padding", "compact");

nexttile;
plot(x, metricTable.R2InSample, "LineWidth", 1.4);
grid on;
ylabel("In-sample R2");
title("Rolling adaptive lasso in-sample fit");

nexttile;
plot(x, metricTable.R2OutOfSample, "LineWidth", 1.2);
hold on;
plot(x, metricTable.R2OutOfSampleVsLastTrainY, "LineWidth", 1.2);
yline(0, "k:");
grid on;
xlabel(localAxisLabel(x));
ylabel("Out-of-sample R2");
title("Forecast R2: 1 - SSE / benchmark SSE");
legend({"vs train mean", "vs last train USDSEK"}, "Location", "best");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function localPlotCorr2(metricTable, fileName, showPlot)
x = metricTable.TrainEnd;
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot));
plot(x, metricTable.Corr2InSample, "LineWidth", 1.4);
hold on;
plot(x, metricTable.Corr2OutOfSample, "LineWidth", 1.4);
grid on;
ylim([0, 1]);
xlabel(localAxisLabel(x));
ylabel("Squared correlation");
title("Rolling adaptive lasso squared-correlation R2");
legend({"In-sample", "Out-of-sample"}, "Location", "best");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function localPlotNegativeOOSDiagnostic(x, yTest, yHatTest, trainMean, ...
    driverTable, r2, fileName, topN)
fig = figure("Color", "w", "Visible", "off");
tiledlayout(2, 1, "TileSpacing", "compact", "Padding", "compact");

nexttile;
plot(x, yTest, "LineWidth", 1.4);
hold on;
plot(x, yHatTest, "--", "LineWidth", 1.4);
plot(x, repmat(trainMean, size(yTest)), ":", "LineWidth", 1.4);
grid on;
xlabel(localAxisLabel(x));
ylabel("USDSEK");
title(sprintf("Negative OOS R2 window: %.4f", r2));
legend({"yTest", "yHatTest", "Training mean benchmark"}, "Location", "best");

nexttile;
[~, order] = sort(abs(driverTable.ExcessSSEContribution), "descend");
order = order(1:min(topN, numel(order)));
[~, displayOrder] = sort(driverTable.ExcessSSEContribution(order), "ascend");
order = order(displayOrder);
values = driverTable.ExcessSSEContribution(order);
bars = barh(values, "FaceColor", "flat");
bars.CData = localContributionColors(values);
xline(0, "k:");
grid on;
yticks(1:numel(order));
yticklabels(driverTable.Term(order));
set(gca, "TickLabelInterpreter", "none");
xlabel("Contribution to model SSE minus benchmark SSE");
title(sprintf("Largest drivers | Model SSE %.4g, benchmark SSE %.4g", ...
    driverTable.ModelSSE(1), driverTable.BenchmarkSSE(1)));
localSaveFigure(fig, fileName);
close(fig);
end

function localPlotNegativeOOSDriverHeatmap(driverTable, fileName, showPlot)
windows = unique(driverTable.Window, "stable");
terms = unique(driverTable.Term, "stable");
contributions = NaN(numel(terms), numel(windows));
for i = 1:numel(terms)
    for j = 1:numel(windows)
        row = driverTable.Window == windows(j) & driverTable.Term == terms(i);
        if any(row)
            contributions(i, j) = driverTable.ExcessSSEContribution(find(row, 1));
        end
    end
end

totalPositive = sum(max(contributions, 0), 2, "omitnan");
[~, order] = sort(totalPositive, "descend");
contributions = contributions(order, :);
terms = terms(order);

figHeight = max(560, 24 * numel(terms));
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot), ...
    "Position", [100, 100, 1200, figHeight]);
imagesc(contributions);
set(gca, "YDir", "normal");
colormap(localDivergingColormap(256));
finiteValues = abs(contributions(isfinite(contributions)));
if ~isempty(finiteValues)
    colorLimit = max(finiteValues);
    if colorLimit > 0
        clim([-colorLimit, colorLimit]);
    end
end
colorbar;
yticks(1:numel(terms));
yticklabels(terms);
set(gca, "TickLabelInterpreter", "none");
tickStep = max(1, ceil(numel(windows) / 12));
tickIndex = unique([1:tickStep:numel(windows), numel(windows)]);
xticks(tickIndex);
xticklabels(string(windows(tickIndex)));
xlabel("Negative-OOS window number");
ylabel("Model term");
title("Excess-SSE contribution by term and negative-OOS window");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function localPlotNegativeOOSDriverTotals(driverTable, fileName, showPlot)
terms = unique(driverTable.Term, "stable");
netContribution = NaN(numel(terms), 1);
positiveContribution = NaN(numel(terms), 1);
negativeContribution = NaN(numel(terms), 1);
for i = 1:numel(terms)
    values = driverTable.ExcessSSEContribution(driverTable.Term == terms(i));
    netContribution(i) = sum(values, "omitnan");
    positiveContribution(i) = sum(max(values, 0), "omitnan");
    negativeContribution(i) = sum(min(values, 0), "omitnan");
end
[~, order] = sort(positiveContribution, "ascend");

figHeight = max(560, 26 * numel(terms));
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot), ...
    "Position", [100, 100, 1050, figHeight]);
barh([positiveContribution(order), negativeContribution(order)], "stacked");
xline(0, "k:");
grid on;
yticks(1:numel(terms));
yticklabels(terms(order));
set(gca, "TickLabelInterpreter", "none");
xlabel("Cumulative excess-SSE contribution");
title("Cumulative drivers across negative-OOS windows");
legend({"Worsened forecasts", "Improved forecasts"}, "Location", "best");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function colors = localContributionColors(values)
colors = repmat([0.20, 0.45, 0.75], numel(values), 1);
colors(values > 0, :) = repmat([0.80, 0.25, 0.20], sum(values > 0), 1);
end

function cmap = localDivergingColormap(n)
half = floor(n / 2);
blue = [linspace(0.15, 1, half).', linspace(0.35, 1, half).', ...
    linspace(0.75, 1, half).'];
red = [linspace(1, 0.75, n - half).', linspace(1, 0.15, n - half).', ...
    linspace(1, 0.12, n - half).'];
cmap = [blue; red];
end

function localPlotCoefficients(coefTable, regressorNames, fileName, showPlot)
x = coefTable.TrainEnd;
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot));
plot(x, coefTable{:, regressorNames}, "LineWidth", 1.0);
yline(0, "k:");
grid on;
xlabel(localAxisLabel(x));
ylabel("beta_j x in-sample std(X_j)");
title("Rolling adaptive lasso standardized coefficient evolution");
legend(regressorNames, "Interpreter", "none", "Location", "eastoutside");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function localPlotAverageCoefficients(averageCoefficientTable, fileName, showPlot)
avgCoef = averageCoefficientTable.AverageStandardizedCoefficient;
names = averageCoefficientTable.Regressor;
[~, order] = sort(abs(avgCoef), "ascend");

figHeight = max(520, 26 * numel(avgCoef));
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot), ...
    "Position", [100, 100, 900, figHeight]);
barh(avgCoef(order), "FaceColor", [0.2, 0.45, 0.7]);
xline(0, "k:");
grid on;
yticks(1:numel(order));
yticklabels(names(order));
set(gca, "TickLabelInterpreter", "none");
xlabel("Average beta_j x in-sample std(X_j)");
title("Average standardized coefficients across rolling windows");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function localPlotCoefficientTurnover(turnoverTable, fileName, showPlot)
x = turnoverTable.TrainEnd;
fig = figure("Color", "w", "Visible", localFigureVisibility(showPlot));
tiledlayout(2, 1, "TileSpacing", "compact", "Padding", "compact");

nexttile;
plot(x, turnoverTable.NormalizedCoefficientTurnover, "LineWidth", 1.3);
grid on;
ylabel("Normalized turnover");
title("Rolling standardized coefficient turnover");

nexttile;
plot(x, turnoverTable.ActiveRegressors, "LineWidth", 1.2);
hold on;
plot(x, turnoverTable.RegressorsAdded, "LineWidth", 1.0);
plot(x, turnoverTable.RegressorsDropped, "LineWidth", 1.0);
grid on;
xlabel(localAxisLabel(x));
ylabel("Count");
legend({"Active", "Added", "Dropped"}, "Location", "best");
localSaveFigure(fig, fileName);
if ~showPlot
    close(fig);
end
end

function visibility = localFigureVisibility(showPlot)
if showPlot
    visibility = "on";
else
    visibility = "off";
end
end

function label = localAxisLabel(x)
if isdatetime(x) || isduration(x)
    label = "Window end date";
else
    label = "Window end observation";
end
end

function localSaveFigure(fig, fileName)
try
    exportgraphics(fig, fileName, "Resolution", 200);
catch
    saveas(fig, fileName);
end
end
