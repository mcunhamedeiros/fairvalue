"""Rolling-window adaptive lasso for USDSEK.

Python translation of computeBetaAdaLasso.m and rollingAdaLassoUSDSEK.m.
By default, the code reads the ``data`` sheet of data_usdsek.xlsx and uses
the same 26 regressors contained in dados_sek.mat.
"""

from __future__ import annotations

import argparse
import json
import math
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import numpy as np
import pandas as pd
from sklearn.linear_model import lasso_path
from statsmodels.tsa.stattools import adfuller


DEFAULT_DATA_FILE = (
    r"C:\Users\marcelom\Dropbox\Consulting\ITAUAM AI\AUDCAD Fairvalue"
    r"\SEK\data_usdsek.xlsx"
)

USDSEK_REGRESSORS = [
    "BBDXY", "EMFX", "OMX", "MSCI_GLOBAL_EX_US", "MSCI_EM", "BCOM",
    "OIL", "GOLD", "NATGAS", "COPPER", "VIX", "MOVE", "USDSEK_RR",
    "ECO_SURPRISE", "SEK_GER_2Y", "SEK_GER_5Y", "SEK_GER_10Y",
    "SEK_GER_3M1M", "SEK_GER_6M1M", "SEK_GER_1Y1M", "ITA_GER_10Y",
    "FRA_GER_10Y", "USD_SEK_EQT_RATIO", "GLOBAL_USD_EQT_RATIO", "POS",
    "POS_CTA",
]


@dataclass
class RollingConfig:
    data_file: str = DEFAULT_DATA_FILE
    dependent_variable: str = "USDSEK"
    estimation_window: int = 756
    test_window: int = 20
    step_size: int = 1
    minimum_train_observations: int = 50
    minimum_test_observations: int = 2
    max_windows: int | None = None
    output_folder: str = "rolling_adalasso_usdsek_outputs_python"
    make_plots: bool = True
    make_negative_oos_plots: bool = True
    save_negative_oos_diagnostics: bool = True
    negative_oos_top_drivers: int = 10
    run_unit_root_test: bool = True
    unit_root_lags: int = 0
    unit_root_alpha: float = 0.05
    n_lambdas: int = 100
    lambda_ratio: float = 1e-4
    verbose: bool = True


def _read_data(file_name: str) -> pd.DataFrame:
    path = Path(file_name)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        frame = pd.read_csv(path)
    elif suffix in {".xlsx", ".xlsm", ".xls"}:
        frame = pd.read_excel(path, sheet_name="data")
    elif suffix in {".parquet", ".pq"}:
        frame = pd.read_parquet(path)
    elif suffix == ".mat":
        raise ValueError(
            "MATLAB tables are not portable through scipy.io.loadmat. Export "
            "the table once with: S=load('dados.mat'); "
            "writetimetable(S.data,'dados.csv'); then pass dados.csv."
        )
    else:
        raise ValueError(f"Unsupported data format: {suffix}")

    if frame.empty:
        raise ValueError("The input data file contains no observations.")

    first = frame.columns[0]
    if first not in frame.select_dtypes(include=[np.number]).columns:
        parsed = pd.to_datetime(frame[first], errors="coerce")
        if parsed.notna().mean() > 0.9:
            frame = frame.drop(columns=first)
            frame.index = parsed
            frame.index.name = "Observation"
    return frame


def _lasso_bic(
    y: np.ndarray,
    x: np.ndarray,
    *,
    standardize: bool,
    dfmax: int,
    n_lambdas: int,
    lambda_ratio: float,
) -> np.ndarray:
    """Select a lasso solution by the BIC formula used in the MATLAB code."""
    y = np.asarray(y, dtype=float).reshape(-1)
    x = np.asarray(x, dtype=float)
    n, p = x.shape
    x_mean = x.mean(axis=0)
    y_mean = y.mean()
    xc = x - x_mean
    yc = y - y_mean

    if standardize:
        scale = xc.std(axis=0, ddof=1)
        scale[~np.isfinite(scale) | (scale <= np.finfo(float).eps)] = 1.0
    else:
        scale = np.ones(p)
    xs = xc / scale

    alpha_max = np.max(np.abs(xs.T @ yc)) / n
    if not np.isfinite(alpha_max) or alpha_max <= np.finfo(float).eps:
        return np.r_[y_mean, np.zeros(p)]
    alphas = np.geomspace(alpha_max, alpha_max * lambda_ratio, n_lambdas)
    _, coefs_scaled, _ = lasso_path(xs, yc, alphas=alphas, max_iter=10000)
    coefs = coefs_scaled / scale[:, None]
    intercepts = y_mean - x_mean @ coefs
    fitted = x @ coefs + intercepts
    mse = np.mean((y[:, None] - fitted) ** 2, axis=0)
    nonzero = np.sum(np.abs(coefs) > 1e-12, axis=0)
    numpar = nonzero + (np.abs(intercepts) > 1e-12)
    bic = np.log(np.maximum(mse, np.finfo(float).tiny)) + np.log(n) * numpar / n
    bic[nonzero > dfmax] = np.inf
    choice = int(np.nanargmin(bic))
    return np.r_[intercepts[choice], coefs[:, choice]]


def compute_beta_adalasso(
    y: np.ndarray,
    x: np.ndarray,
    *,
    n_lambdas: int = 100,
    lambda_ratio: float = 1e-4,
) -> tuple[np.ndarray, np.ndarray]:
    """Two-stage adaptive lasso equivalent to computeBetaAdaLasso.m."""
    y = np.asarray(y, dtype=float).reshape(-1)
    x = np.asarray(x, dtype=float)
    n = y.size
    dfmax = round(n**0.9)
    initial = _lasso_bic(
        y, x, standardize=True, dfmax=dfmax,
        n_lambdas=n_lambdas, lambda_ratio=lambda_ratio,
    )
    weights = 1.0 / (np.abs(initial[1:]) + 1.0 / math.sqrt(n))
    z = x / weights
    adaptive_z = _lasso_bic(
        y, z, standardize=False, dfmax=dfmax,
        n_lambdas=n_lambdas, lambda_ratio=lambda_ratio,
    )
    beta = np.r_[adaptive_z[0], adaptive_z[1:] / weights]
    residuals = y - (beta[0] + x @ beta[1:])
    return beta, residuals


def _r2(y: np.ndarray, yhat: np.ndarray, benchmark: float) -> float:
    denominator = np.sum((y - benchmark) ** 2)
    return np.nan if denominator <= np.finfo(float).eps else 1 - np.sum((y - yhat) ** 2) / denominator


def _corr2(y: np.ndarray, yhat: np.ndarray) -> float:
    if y.size < 2 or np.std(y) <= np.finfo(float).eps or np.std(yhat) <= np.finfo(float).eps:
        return np.nan
    return float(np.corrcoef(y, yhat)[0, 1] ** 2)


def _negative_oos_drivers(
    window: int,
    start_index: int,
    train_start: Any,
    train_end: Any,
    test_start: Any,
    test_end: Any,
    y_train: np.ndarray,
    x_train: np.ndarray,
    y_test: np.ndarray,
    x_test: np.ndarray,
    yhat_test: np.ndarray,
    beta: np.ndarray,
    regressor_names: list[str],
    oos_r2: float,
) -> pd.DataFrame:
    benchmark = float(np.mean(y_train))
    benchmark_error = y_test - benchmark
    model_error = y_test - yhat_test
    total_gap = yhat_test - benchmark
    term_names = ["Intercept", *regressor_names]
    term_types = ["Intercept", *(["Regressor"] * len(regressor_names))]
    sample_std = np.r_[np.nan, np.std(x_train, axis=0, ddof=1)]
    standardized_beta = np.r_[np.nan, beta[1:] * sample_std[1:]]
    train_mean_x = np.r_[np.nan, np.mean(x_train, axis=0)]
    test_mean_x = np.r_[np.nan, np.mean(x_test, axis=0)]
    forecast_contrib = np.column_stack([np.full(y_test.size, beta[0]), x_test * beta[1:]])
    benchmark_gap_contrib = forecast_contrib.copy()
    benchmark_gap_contrib[:, 0] -= benchmark
    excess_contrib = np.sum(benchmark_gap_contrib * (total_gap - 2 * benchmark_error)[:, None], axis=0)
    positive = np.maximum(excess_contrib, 0)
    shares = positive / positive.sum() if positive.sum() > np.finfo(float).eps else np.full_like(positive, np.nan)
    ranks = np.full(len(term_names), np.nan)
    order = np.argsort(-positive)
    for rank, idx in enumerate(order, start=1):
        if positive[idx] > 0:
            ranks[idx] = rank
    model_sse = np.sum(model_error**2)
    benchmark_sse = np.sum(benchmark_error**2)
    return pd.DataFrame({
        "Window": window, "StartIndex": start_index,
        "TrainStart": train_start, "TrainEnd": train_end,
        "TestStart": test_start, "TestEnd": test_end,
        "DriverRank": ranks, "Term": term_names, "TermType": term_types,
        "RawBeta": beta, "InSampleStd": sample_std,
        "StandardizedBeta": standardized_beta,
        "TrainMeanX": train_mean_x, "TestMeanX": test_mean_x,
        "MeanForecastContribution": forecast_contrib.mean(axis=0),
        "MeanBenchmarkGapContribution": benchmark_gap_contrib.mean(axis=0),
        "MeanAbsBenchmarkGapContribution": np.abs(benchmark_gap_contrib).mean(axis=0),
        "ExcessSSEContribution": excess_contrib,
        "PositiveExcessSSEShare": shares,
        "ModelSSE": model_sse, "BenchmarkSSE": benchmark_sse,
        "ExcessSSE": model_sse - benchmark_sse,
        "R2OutOfSample": oos_r2, "TrainMeanUSDSEK": benchmark,
        "TestMeanUSDSEK": np.mean(y_test), "MeanYHatTest": np.mean(yhat_test),
    })


def _savefig(fig: plt.Figure, file_name: Path) -> None:
    fig.savefig(file_name, dpi=200, bbox_inches="tight")
    plt.close(fig)


def _negative_window_plot(
    x_axis: pd.Index,
    y_test: np.ndarray,
    yhat_test: np.ndarray,
    train_mean: float,
    drivers: pd.DataFrame,
    oos_r2: float,
    file_name: Path,
    top_n: int,
) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(12, 8), constrained_layout=True)
    axes[0].plot(x_axis, y_test, label="yTest", linewidth=1.5)
    axes[0].plot(x_axis, yhat_test, "--", label="yHatTest", linewidth=1.5)
    axes[0].axhline(train_mean, linestyle=":", color="#d89b00", label="Training mean benchmark")
    axes[0].set_title(f"Negative OOS R2 window: {oos_r2:.4f}")
    axes[0].set_ylabel("USDSEK")
    axes[0].grid(alpha=0.3)
    axes[0].legend()
    selected = drivers.iloc[np.argsort(-np.abs(drivers["ExcessSSEContribution"].to_numpy()))[:top_n]].copy()
    selected = selected.sort_values("ExcessSSEContribution")
    values = selected["ExcessSSEContribution"].to_numpy()
    colors = np.where(values > 0, "#cc4035", "#3778bf")
    axes[1].barh(selected["Term"], values, color=colors)
    axes[1].axvline(0, color="black", linestyle=":", linewidth=1)
    axes[1].grid(axis="x", alpha=0.3)
    axes[1].set_xlabel("Contribution to model SSE minus benchmark SSE")
    axes[1].set_title(
        f"Largest drivers | Model SSE {drivers['ModelSSE'].iloc[0]:.4g}, "
        f"benchmark SSE {drivers['BenchmarkSSE'].iloc[0]:.4g}"
    )
    _savefig(fig, file_name)


def _plot_main_results(
    metrics: pd.DataFrame,
    standardized: pd.DataFrame,
    averages: pd.DataFrame,
    turnover: pd.DataFrame,
    drivers: pd.DataFrame,
    regressor_names: list[str],
    output: Path,
) -> None:
    x = metrics["TrainEnd"]
    fig, ax = plt.subplots(2, 1, figsize=(12, 8), constrained_layout=True)
    ax[0].plot(x, metrics["R2InSample"], linewidth=1.3)
    ax[0].set(title="Rolling adaptive lasso in-sample fit", ylabel="In-sample R2")
    ax[1].plot(x, metrics["R2OutOfSample"], label="vs train mean")
    ax[1].plot(x, metrics["R2OutOfSampleVsLastTrainY"], label="vs last train USDSEK")
    ax[1].axhline(0, color="black", linestyle=":")
    ax[1].set(title="Forecast R2: 1 - SSE / benchmark SSE", ylabel="Out-of-sample R2")
    ax[1].legend()
    for a in ax: a.grid(alpha=0.3)
    _savefig(fig, output / "rollingAdaLasso_R2.png")

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(x, metrics["Corr2InSample"], label="In-sample")
    ax.plot(x, metrics["Corr2OutOfSample"], label="Out-of-sample")
    ax.set_ylim(0, 1); ax.grid(alpha=0.3); ax.legend()
    ax.set(title="Rolling adaptive lasso squared-correlation R2", ylabel="Squared correlation")
    _savefig(fig, output / "rollingAdaLasso_corr2.png")

    fig, ax = plt.subplots(figsize=(14, 7))
    for name in regressor_names: ax.plot(standardized["TrainEnd"], standardized[name], label=name, linewidth=0.8)
    ax.axhline(0, color="black", linestyle=":"); ax.grid(alpha=0.25)
    ax.set(title="Rolling adaptive lasso standardized coefficient evolution", ylabel="beta_j x in-sample std(X_j)")
    ax.legend(loc="center left", bbox_to_anchor=(1, 0.5), fontsize=8)
    _savefig(fig, output / "rollingAdaLasso_coefficients.png")

    avg = averages.sort_values("AverageStandardizedCoefficient", key=np.abs)
    fig, ax = plt.subplots(figsize=(10, max(6, 0.32 * len(avg))))
    ax.barh(avg["Regressor"], avg["AverageStandardizedCoefficient"], color="#3373ad")
    ax.axvline(0, color="black", linestyle=":"); ax.grid(axis="x", alpha=0.3)
    ax.set(title="Average standardized coefficients across rolling windows", xlabel="Average beta_j x in-sample std(X_j)")
    _savefig(fig, output / "rollingAdaLasso_average_coefficients.png")

    fig, ax = plt.subplots(2, 1, figsize=(12, 8), constrained_layout=True)
    ax[0].plot(turnover["TrainEnd"], turnover["NormalizedCoefficientTurnover"])
    ax[0].set(title="Rolling standardized coefficient turnover", ylabel="Normalized turnover")
    for name in ["ActiveRegressors", "RegressorsAdded", "RegressorsDropped"]:
        ax[1].plot(turnover["TrainEnd"], turnover[name], label=name)
    ax[1].set_ylabel("Count"); ax[1].legend()
    for a in ax: a.grid(alpha=0.3)
    _savefig(fig, output / "rollingAdaLasso_coefficient_turnover.png")

    if drivers.empty:
        return
    matrix = drivers.pivot(index="Term", columns="Window", values="ExcessSSEContribution")
    order = matrix.clip(lower=0).sum(axis=1).sort_values(ascending=False).index
    matrix = matrix.loc[order]
    bound = np.nanmax(np.abs(matrix.to_numpy()))
    fig, ax = plt.subplots(figsize=(15, max(7, 0.35 * len(matrix))))
    im = ax.imshow(matrix, aspect="auto", cmap="coolwarm", norm=TwoSlopeNorm(vcenter=0, vmin=-bound, vmax=bound))
    ax.set_yticks(np.arange(len(matrix))); ax.set_yticklabels(matrix.index)
    ticks = np.unique(np.r_[np.arange(0, matrix.shape[1], max(1, math.ceil(matrix.shape[1] / 12))), matrix.shape[1] - 1])
    ax.set_xticks(ticks); ax.set_xticklabels(matrix.columns[ticks], rotation=45, ha="right")
    ax.set(title="Excess-SSE contribution by term and negative-OOS window", xlabel="Negative-OOS window", ylabel="Model term")
    fig.colorbar(im, ax=ax)
    _savefig(fig, output / "negative_oos_driver_heatmap.png")

    totals = drivers.groupby("Term")["ExcessSSEContribution"].agg(
        Harmful=lambda s: s.clip(lower=0).sum(), Helpful=lambda s: s.clip(upper=0).sum()
    ).sort_values("Harmful")
    fig, ax = plt.subplots(figsize=(11, max(7, 0.36 * len(totals))))
    ax.barh(totals.index, totals["Harmful"], color="#cc4035", label="Worsened forecasts")
    ax.barh(totals.index, totals["Helpful"], color="#3778bf", label="Improved forecasts")
    ax.axvline(0, color="black", linestyle=":"); ax.grid(axis="x", alpha=0.3); ax.legend()
    ax.set(title="Cumulative drivers across negative-OOS windows", xlabel="Cumulative excess-SSE contribution")
    _savefig(fig, output / "negative_oos_driver_totals.png")


def rolling_adalasso_usdsek(config: RollingConfig) -> dict[str, Any]:
    cfg = config
    data = _read_data(cfg.data_file)
    if cfg.dependent_variable not in data.columns:
        raise ValueError(f"Dependent variable {cfg.dependent_variable!r} was not found.")
    numeric = data.select_dtypes(include=[np.number])
    missing_regressors = [name for name in USDSEK_REGRESSORS if name not in numeric.columns]
    if missing_regressors:
        raise ValueError(f"Missing USDSEK regressors: {missing_regressors}")
    regressor_names = USDSEK_REGRESSORS.copy()
    y_all = pd.to_numeric(data[cfg.dependent_variable], errors="coerce").to_numpy(float)
    x_all = numeric[regressor_names].to_numpy(float)
    obs = data.index
    n = len(data)
    last_start = n - cfg.estimation_window - cfg.test_window
    if last_start < 0:
        raise ValueError("Sample is too short for the requested windows.")
    starts = list(range(0, last_start + 1, cfg.step_size))
    if cfg.max_windows is not None: starts = starts[:cfg.max_windows]
    output = Path(cfg.output_folder); output.mkdir(parents=True, exist_ok=True)
    neg_folder = output / "negative_oos_plots"
    if cfg.make_negative_oos_plots: neg_folder.mkdir(parents=True, exist_ok=True)

    coef_rows, stdcoef_rows, std_rows, metric_rows, pred_rows, driver_rows = [], [], [], [], [], []
    previous_stdcoef = None
    turnover_rows = []
    for position, start in enumerate(starts, start=1):
        train_idx = np.arange(start, start + cfg.estimation_window)
        test_idx = np.arange(train_idx[-1] + 1, train_idx[-1] + 1 + cfg.test_window)
        train_good = np.isfinite(y_all[train_idx]) & np.all(np.isfinite(x_all[train_idx]), axis=1)
        test_good = np.isfinite(y_all[test_idx]) & np.all(np.isfinite(x_all[test_idx]), axis=1)
        y_train, x_train = y_all[train_idx][train_good], x_all[train_idx][train_good]
        y_test, x_test = y_all[test_idx][test_good], x_all[test_idx][test_good]
        info = {"Window": position, "StartIndex": start + 1,
                "TrainStart": obs[train_idx[0]], "TrainEnd": obs[train_idx[-1]],
                "TestStart": obs[test_idx[0]], "TestEnd": obs[test_idx[-1]]}
        if len(y_train) < cfg.minimum_train_observations or len(y_test) < cfg.minimum_test_observations:
            metric_rows.append({**info, "Status": "Skipped: too few usable observations"})
            continue
        try:
            beta, residuals = compute_beta_adalasso(y_train, x_train, n_lambdas=cfg.n_lambdas, lambda_ratio=cfg.lambda_ratio)
            yhat_train = beta[0] + x_train @ beta[1:]
            yhat_test = beta[0] + x_test @ beta[1:]
            sample_std = np.std(x_train, axis=0, ddof=1)
            stdcoef = beta[1:] * sample_std
            train_mean = float(np.mean(y_train))
            oos_r2 = _r2(y_test, yhat_test, train_mean)
            try:
                if cfg.run_unit_root_test:
                    adf = adfuller(residuals, maxlag=cfg.unit_root_lags, regression="c", autolag=None)
                    adf_reject, adf_p, adf_stat = float(adf[1] < cfg.unit_root_alpha), float(adf[1]), float(adf[0])
                    adf_critical, adf_status = float(adf[4]["5%"]), "OK"
                else:
                    adf_reject = adf_p = adf_stat = adf_critical = np.nan; adf_status = "Skipped"
            except Exception as exc:
                adf_reject = adf_p = adf_stat = adf_critical = np.nan; adf_status = f"Skipped: {exc}"
            recent = slice(max(0, len(y_train) - cfg.test_window), len(y_train))
            metric = {**info, "TrainObservations": len(y_train), "TestObservations": len(y_test),
                "ActiveRegressors": int(np.sum(np.abs(beta[1:]) > 1e-12)),
                "R2InSample": _r2(y_train, yhat_train, train_mean), "R2OutOfSample": oos_r2,
                "R2OutOfSampleVsTrainMean": oos_r2,
                "R2OutOfSampleVsLastTrainY": _r2(y_test, yhat_test, y_train[-1]),
                "Corr2InSample": _corr2(y_train, yhat_train), "Corr2OutOfSample": _corr2(y_test, yhat_test),
                "RMSEInSample": np.sqrt(np.mean((y_train-yhat_train)**2)),
                "RMSEOutOfSample": np.sqrt(np.mean((y_test-yhat_test)**2)),
                "MAEOutOfSample": np.mean(np.abs(y_test-yhat_test)), "TestStd": np.std(y_test, ddof=1),
                "TestRange": np.ptp(y_test), "LastTrainUSDSEK": y_train[-1], "LastTrainFitted": yhat_train[-1],
                "LastTrainResidual": y_train[-1]-yhat_train[-1],
                "RecentTrainRMSE": np.sqrt(np.mean((y_train[recent]-yhat_train[recent])**2)),
                "UnitRootReject": adf_reject, "UnitRootPValue": adf_p, "UnitRootStatistic": adf_stat,
                "UnitRootCriticalValue": adf_critical, "UnitRootStatus": adf_status,
                "NegativeOOSPlotFile": "", "Status": "OK"}
            if oos_r2 < 0 and (cfg.make_negative_oos_plots or cfg.save_negative_oos_diagnostics):
                window_drivers = _negative_oos_drivers(position, start + 1, info["TrainStart"], info["TrainEnd"], info["TestStart"], info["TestEnd"], y_train, x_train, y_test, x_test, yhat_test, beta, regressor_names, oos_r2)
                if cfg.save_negative_oos_diagnostics: driver_rows.append(window_drivers)
                if cfg.make_negative_oos_plots:
                    plot_file = neg_folder / f"negative_oos_window_{position:04d}.png"
                    _negative_window_plot(obs[test_idx[test_good]], y_test, yhat_test, train_mean, window_drivers, oos_r2, plot_file, cfg.negative_oos_top_drivers)
                    metric["NegativeOOSPlotFile"] = str(plot_file)
            metric_rows.append(metric)
            coef_rows.append({**info, "Intercept": beta[0], **dict(zip(regressor_names, beta[1:]))})
            stdcoef_rows.append({**info, **dict(zip(regressor_names, stdcoef))})
            std_rows.append({**info, **dict(zip(regressor_names, sample_std))})
            if previous_stdcoef is None:
                turn = [np.nan] * 4 + [int(np.sum(np.abs(stdcoef)>1e-12)), np.nan, np.nan]
            else:
                delta = stdcoef - previous_stdcoef; scale = np.sum(np.abs(previous_stdcoef))
                active = np.abs(stdcoef)>1e-12; old_active = np.abs(previous_stdcoef)>1e-12
                turn = [np.sum(np.abs(delta)), np.sum(np.abs(delta))/max(scale,np.finfo(float).eps), np.mean(np.abs(delta)), np.max(np.abs(delta)), int(active.sum()), int(np.sum(active & ~old_active)), int(np.sum(~active & old_active))]
            turnover_rows.append({**info, **dict(zip(["AbsoluteCoefficientTurnover","NormalizedCoefficientTurnover","MeanAbsCoefficientChange","MaxAbsCoefficientChange","ActiveRegressors","RegressorsAdded","RegressorsDropped"], turn))})
            previous_stdcoef = stdcoef.copy()
            for axis_value, actual, forecast in zip(obs[test_idx[test_good]], y_test, yhat_test):
                pred_rows.append({"Window":position,"Observation":axis_value,"USDSEK":actual,"Prediction":forecast,"Error":actual-forecast,"TrainMean":train_mean,"LastTrainUSDSEK":y_train[-1]})
        except Exception as exc:
            metric_rows.append({**info, "Status": f"Skipped: {exc}"})
            warnings.warn(f"Window {position} skipped: {exc}")
        if cfg.verbose and (position % 100 == 0 or position == len(starts)):
            print(f"Finished {position} of {len(starts)} windows")

    coef = pd.DataFrame(coef_rows); standardized = pd.DataFrame(stdcoef_rows); reg_std = pd.DataFrame(std_rows)
    metrics = pd.DataFrame(metric_rows); turnover = pd.DataFrame(turnover_rows); predictions = pd.DataFrame(pred_rows)
    drivers = pd.concat(driver_rows, ignore_index=True) if driver_rows else pd.DataFrame()
    averages = pd.DataFrame({"Regressor":regressor_names,
        "AverageRawCoefficient":[coef[n].mean() for n in regressor_names],
        "AverageStandardizedCoefficient":[standardized[n].mean() for n in regressor_names],
        "AverageInSampleStd":[reg_std[n].mean() for n in regressor_names]})
    unit_root_cols = ["Window","StartIndex","TrainStart","TrainEnd","TestStart","TestEnd","UnitRootReject","UnitRootPValue","UnitRootStatistic","UnitRootCriticalValue","UnitRootStatus"]
    unit_root = metrics.reindex(columns=unit_root_cols)
    files = {"rollingAdaLassoCoefficients.csv":coef, "rollingAdaLassoStandardizedCoefficients.csv":standardized,
        "rollingAdaLassoRegressorStd.csv":reg_std, "rollingAdaLassoAverageCoefficients.csv":averages,
        "rollingAdaLassoCoefficientTurnover.csv":turnover, "rollingAdaLassoR2.csv":metrics,
        "rollingAdaLassoUnitRoot.csv":unit_root, "rollingAdaLassoPredictions.csv":predictions,
        "rollingAdaLassoNegativeOOSDrivers.csv":drivers}
    for name, frame in files.items(): frame.to_csv(output / name, index=False)
    (output / "rollingAdaLassoConfig.json").write_text(json.dumps(asdict(cfg), indent=2), encoding="utf-8")
    if cfg.make_plots: _plot_main_results(metrics, standardized, averages, turnover, drivers, regressor_names, output)
    return {"config": cfg, "regressor_names": regressor_names, "coefficients": coef,
        "standardized_coefficients": standardized, "metrics": metrics, "unit_root": unit_root,
        "predictions": predictions, "negative_oos_drivers": drivers, "coefficient_turnover": turnover}


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("data_file", nargs="?", default=DEFAULT_DATA_FILE,
        help="USDSEK Excel, CSV, or Parquet file (default: data_usdsek.xlsx)")
    p.add_argument("--output-folder", default="rolling_adalasso_usdsek_outputs_python")
    p.add_argument("--estimation-window", type=int, default=756)
    p.add_argument("--test-window", type=int, default=20)
    p.add_argument("--step-size", type=int, default=1)
    p.add_argument("--max-windows", type=int)
    p.add_argument("--no-plots", action="store_true")
    p.add_argument("--no-negative-oos-plots", action="store_true")
    p.add_argument("--no-unit-root-test", action="store_true")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    cfg = RollingConfig(data_file=args.data_file, output_folder=args.output_folder,
        estimation_window=args.estimation_window, test_window=args.test_window,
        step_size=args.step_size, max_windows=args.max_windows,
        make_plots=not args.no_plots, make_negative_oos_plots=not args.no_negative_oos_plots,
        run_unit_root_test=not args.no_unit_root_test)
    rolling_adalasso_usdsek(cfg)
